#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Antena Companion.

Script mode  (RunScript(script.antena.companion,recommendations)):
    Recommendations built from Kodi's own EPG database (PVR.GetBroadcasts):
    programmes airing now / soon, filtered by the user's preferences from
    the settings (default: movies, genres learned from the viewing history)
    and shown as a summary of upcoming programmes, planned items
    (reminders + timers) and recordings. Pick a programme to tune its
    channel, schedule a recording or read the description.

Script mode  (RunScript(script.antena.companion,rec_open,<G|P|R>,<n>)):
    Action dialog for one row of the home-screen condensed views.

VOD mode     (RunScript(script.antena.companion,vod|vod_movies|vod_series)):
    "Movies on TV" / "Series on TV" poster-wall window of upcoming movies
    and series (up to 14 days of guide), grouped by genre, with reminders,
    recording timers, series rules and a planning manager. Fully offline:
    posters fall back to the channel icon or the channel name. Optional
    enrichment from the Kodi video library (ratings, posters written there
    by its scrapers) is OFF by default because those scrapers need internet.

Plan mode    (RunScript(script.antena.companion,plan)):
    Planning manager: upcoming reminders + recording timers, cancel them.

Service mode (service.py):
    Remembers the last played channel and the genres watched, replays the
    last channel at Kodi startup, fires the VOD reminders and refreshes the
    condensed views shown when hovering the home-screen tabs (Przewodnik /
    Rekomendowane / Filmy w TV / Seriale w TV ...) as Home window
    properties – the skin previews stay fully offline.

No tvheadend connection is needed: everything comes from Kodi JSON-RPC.
"""

import sys
import os
import json
import time
from datetime import datetime, timedelta, timezone

try:
    import xbmc
    import xbmcgui
    import xbmcaddon
    import xbmcvfs
except ImportError:  # allow syntax checks outside Kodi
    xbmc = xbmcgui = xbmcaddon = xbmcvfs = None

ADDON_ID = 'script.antena.companion'
STATE_DIR = 'special://userdata/addon_data/{}/'.format(ADDON_ID)
STATE_FILE = STATE_DIR + 'state.json'


# ----------------------------------------------------------------------------
# Addon helpers
# ----------------------------------------------------------------------------
class Addon:
    _inst = None

    @classmethod
    def get(cls):
        if cls._inst is None and xbmcaddon is not None:
            cls._inst = xbmcaddon.Addon(ADDON_ID)
        return cls._inst

    @classmethod
    def setting(cls, key, default=None):
        try:
            v = cls.get().getSetting(key)
            return default if v in ('', None) else v
        except Exception:
            return default

    @classmethod
    def setting_bool(cls, key, default=False):
        v = cls.setting(key)
        return default if v is None else str(v).lower() in ('true', '1', 'yes', 'on')

    @classmethod
    def setting_int(cls, key, default=0):
        try:
            return int(cls.setting(key, default))
        except (ValueError, TypeError):
            return default

    @classmethod
    def L(cls, sid):
        try:
            return cls.get().getLocalizedString(sid)
        except Exception:
            return str(sid)


def log(msg, level='info'):
    if xbmc is None:
        print('[antena] {}'.format(msg))
        return
    if level == 'debug' and not Addon.setting_bool('debug_log', False):
        return
    lv = {'debug': xbmc.LOGDEBUG, 'info': xbmc.LOGINFO, 'error': xbmc.LOGERROR}.get(level, xbmc.LOGINFO)
    xbmc.log('[{}] {}'.format(ADDON_ID, msg), lv)


# ----------------------------------------------------------------------------
# State
# ----------------------------------------------------------------------------
def _state_default():
    return {'last_channel_id': None, 'last_channel_name': None,
            'last_channel_type': None, 'last_played_at': 0, 'genres': {}}


def load_state():
    st = _state_default()
    try:
        if xbmcvfs is None:
            path = os.path.expanduser('~/.antena-companion/state.json')
            if os.path.exists(path):
                st.update(json.load(open(path)))
            return st
        if xbmcvfs.exists(STATE_FILE):
            f = xbmcvfs.File(STATE_FILE)
            raw = f.read()
            f.close()
            if raw:
                st.update(json.loads(raw))
    except Exception as e:
        log('load_state failed: {}'.format(e), 'error')
    return st


def save_state(st):
    try:
        raw = json.dumps(st, indent=2)
        if xbmcvfs is None:
            os.makedirs(os.path.expanduser('~/.antena-companion'), exist_ok=True)
            open(os.path.expanduser('~/.antena-companion/state.json'), 'w').write(raw)
            return
        if not xbmcvfs.exists(STATE_DIR):
            xbmcvfs.mkdirs(STATE_DIR)
        f = xbmcvfs.File(STATE_FILE, 'w')
        f.write(raw)
        f.close()
    except Exception as e:
        log('save_state failed: {}'.format(e), 'error')


# ----------------------------------------------------------------------------
# Kodi JSON-RPC
# ----------------------------------------------------------------------------
def jsonrpc(method, params=None):
    if xbmc is None:
        return {}
    payload = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params is not None:
        payload['params'] = params
    try:
        d = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
        if d.get('error'):
            log('jsonrpc error {}: {}'.format(method, d['error']), 'error')
        return d.get('result', {}) or {}
    except Exception as e:
        log('jsonrpc {} failed: {}'.format(method, e), 'error')
        return {}


def get_channels(channel_type='tv'):
    # Prefer 'icon' when the backend supports it; fall back to the minimal
    # property set known to work on pvr.hts.
    r = jsonrpc('PVR.GetChannels', {
        'channelgroupid': 'all' + channel_type,
        'properties': ['channel', 'channeltype', 'hidden', 'locked', 'icon']})
    chans = r.get('channels', []) if isinstance(r, dict) else []
    if not chans:
        r = jsonrpc('PVR.GetChannels', {
            'channelgroupid': 'all' + channel_type,
            'properties': ['channel', 'channeltype', 'hidden', 'locked']})
        chans = r.get('channels', []) if isinstance(r, dict) else []
    return [c for c in chans if not c.get('hidden') and not c.get('locked')]


BROADCAST_PROPS = ['title', 'plot', 'starttime', 'endtime', 'runtime',
                   'genre', 'hastimer', 'isactive', 'wasactive', 'thumbnail']


def get_broadcasts(channel_id, count=12):
    r = jsonrpc('PVR.GetBroadcasts', {
        'channelid': int(channel_id),
        'properties': BROADCAST_PROPS,
        'limits': {'start': 0, 'end': count}})
    return r.get('broadcasts', []) if isinstance(r, dict) else []


def is_pvr_ready():
    r = jsonrpc('PVR.GetProperties', {'properties': ['available']})
    return bool(r.get('available')) if isinstance(r, dict) else False


def play_channel(channel_id):
    if not channel_id:
        return False
    jsonrpc('Player.Open', {'item': {'channelid': int(channel_id)}})
    return True


def _parse(s):
    return datetime.strptime(s, '%Y-%m-%d %H:%M:%S')


def detect_utc(broadcasts, force=None):
    """Decide whether PVR starttime/endtime values are UTC or local.

    Strategy:
      1. If the user forced a mode via setting 'epg_times_utc', honour it.
      2. Look at programmes marked isactive and score both interpretations
         (UTC vs local) by how well the interval covers wall-clock "now".
      3. Prefer the mode with more matching active programmes.
      4. When still ambiguous, prefer *local* time (safer for typical
         European / Polish PVR backends such as tvheadend).

    Returns True  → treat times as UTC
            False → treat times as already local
    """
    if force is not None:
        return bool(force)

    # User override from settings ('auto' / '' = detect, 'utc', 'local')
    override = (Addon.setting('epg_times_utc', 'auto') or 'auto').strip().lower()
    if override in ('utc', 'true', '1', 'yes'):
        log('EPG times forced to UTC by setting', 'debug')
        return True
    if override in ('local', 'false', '0', 'no'):
        log('EPG times forced to local by setting', 'debug')
        return False

    now_utc = datetime.utcnow()
    now_loc = datetime.now()
    score_utc = 0
    score_loc = 0
    samples = 0

    for b in broadcasts:
        if not b.get('isactive'):
            continue
        try:
            s = _parse(b['starttime'])
            e = _parse(b['endtime'])
        except Exception:
            continue
        samples += 1
        # How many minutes the programme "covers" the respective clock
        if s <= now_utc <= e:
            score_utc += 1
        if s <= now_loc <= e:
            score_loc += 1

    if samples == 0:
        # No currently-airing programme in the sample → default to local
        # (most home PVR setups in PL/EU return local wall time).
        log('detect_utc: no isactive samples → defaulting to local', 'debug')
        return False

    if score_utc > score_loc:
        log('detect_utc: UTC wins ({} vs {} local) from {} samples'.format(
            score_utc, score_loc, samples), 'debug')
        return True
    if score_loc > score_utc:
        log('detect_utc: local wins ({} vs {} UTC) from {} samples'.format(
            score_loc, score_utc, samples), 'debug')
        return False

    # Tie or both zero → prefer local
    log('detect_utc: tie/ambiguous (utc={} loc={} samples={}) → local'.format(
        score_utc, score_loc, samples), 'debug')
    return False


def to_local(s, is_utc):
    """Convert a PVR timestamp string to naive local datetime."""
    dt = _parse(s)
    if is_utc:
        return dt.replace(tzinfo=timezone.utc).astimezone().replace(tzinfo=None)
    return dt


def genre_of(b):
    g = b.get('genre') or []
    if isinstance(g, str):
        g = [g]
    g = [x.strip() for x in g if x and x.strip()]
    return g[0] if g else ''


# ----------------------------------------------------------------------------
# Day naming (fully offline – no scrapers, no internet)
# ----------------------------------------------------------------------------
_WEEKDAYS_PL = ['poniedziałek', 'wtorek', 'środę', 'czwartek', 'piątek',
                'sobotę', 'niedzielę']
_WEEKDAYS_EN = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday',
                'Saturday', 'Sunday']


def ui_language():
    """'pl' when the UI language is Polish, else 'en'."""
    if xbmc is None:
        return 'en'
    try:
        lang = (xbmc.getInfoLabel('System.Language') or '').lower()
        if 'pol' in lang or 'polsk' in lang:
            return 'pl'
    except Exception:
        pass
    return 'en'


def day_name(epoch):
    """Human day for a timestamp: today / tomorrow / day after tomorrow /
    'on Friday' (next 7 days) / dd.mm for anything further."""
    from datetime import date as _date
    d0, d1 = _date.today(), _date.fromtimestamp(int(epoch))
    diff = (d1 - d0).days
    if diff <= 0:
        return Addon.L(32329)          # today
    if diff == 1:
        return Addon.L(32330)          # tomorrow
    if diff == 2:
        return Addon.L(32354)          # day after tomorrow
    if diff <= 6:
        wd = d1.weekday()
        if ui_language() == 'pl':
            return ('we ' if wd == 1 else 'w ') + _WEEKDAYS_PL[wd]
        return 'on ' + _WEEKDAYS_EN[wd]
    return d1.strftime('%d.%m')


# ----------------------------------------------------------------------------
# Recommendations (EPG based)
# ----------------------------------------------------------------------------
def collect_epg(horizon_hours, silent=False):
    """Return list of entries for programmes airing now or starting within the
    horizon: {channelid, channel, title, plot, start, end, genre, now, timer,
    broadcastid}.

    silent=True skips the progress dialog (used by the background service for
    the home-screen condensed views).
    """
    dlg = None
    if not silent and xbmcgui is not None:
        dlg = xbmcgui.DialogProgress()
        dlg.create(Addon.L(32101), Addon.L(32102))
    channels = get_channels('tv')
    entries = []
    # Collect a small sample of broadcasts first so we can decide UTC vs local
    # once, using programmes that are actually marked isactive.
    sample_bs = []
    for ch in channels[:12]:
        sample_bs.extend(get_broadcasts(ch['channelid'], count=8))
        if sum(1 for b in sample_bs if b.get('isactive')) >= 3:
            break
    utc_mode = detect_utc(sample_bs)
    log('EPG time mode: {}'.format('UTC' if utc_mode else 'local'), 'info')

    now = datetime.now()
    limit = now + timedelta(hours=horizon_hours)
    total = max(len(channels), 1)
    for i, ch in enumerate(channels):
        if dlg is not None:
            if dlg.iscanceled():
                dlg.close()
                return None
            dlg.update(int(i * 100 / total), ch.get('label') or ch.get('channel') or '')
        bs = get_broadcasts(ch['channelid'])
        for b in bs:
            if b.get('wasactive') and not b.get('isactive'):
                continue
            try:
                st, en = to_local(b['starttime'], utc_mode), to_local(b['endtime'], utc_mode)
            except Exception:
                continue
            if en <= now or st > limit:
                continue
            entries.append({
                'channelid': ch['channelid'],
                'channel': ch.get('label') or ch.get('channel') or '?',
                'chicon': ch.get('icon') or '',
                'title': b.get('title') or '?',
                'plot': b.get('plot') or '',
                'start': st, 'end': en,
                'genre': genre_of(b),
                'runtime': b.get('runtime') or 0,
                'now': bool(b.get('isactive')) or st <= now,
                'timer': bool(b.get('hastimer')),
                'broadcastid': b.get('broadcastid'),
                'thumb': b.get('thumbnail') or '',
            })
    if dlg is not None:
        dlg.close()
    log('EPG scan: {} channels, {} programmes (mode={})'.format(
        len(channels), len(entries), 'UTC' if utc_mode else 'local'), 'info')
    return entries


def _entry_label(e):
    when = Addon.L(32114) if e['now'] else e['start'].strftime('%H:%M')
    mark = ' \u23fa' if e['timer'] else ''
    return '[{}] {} \u2014 {}{}'.format(when, e['channel'], e['title'], mark)


def _entry_actions(e):
    dlg = xbmcgui.Dialog()
    while True:
        head = '{} ({} - {})'.format(e['title'], e['start'].strftime('%H:%M'), e['end'].strftime('%H:%M'))
        opts = [Addon.L(32116), Addon.L(32117), Addon.L(32118), Addon.L(32119)]
        sel = dlg.select(head, opts)
        if sel == 0:
            play_channel(e['channelid'])
            return 'played'
        if sel == 1:
            if e.get('broadcastid'):
                r = jsonrpc('PVR.AddTimer', {'broadcastid': int(e['broadcastid'])})
                ok = bool(r)
                dlg.notification(Addon.L(32101), Addon.L(32120 if ok else 32121), time=3000)
            else:
                dlg.notification(Addon.L(32101), Addon.L(32121), time=3000)
        elif sel == 2:
            dlg.textviewer(head, e['plot'] or Addon.L(32122))
        else:
            return 'back'


def _show_list(title, items):
    dlg = xbmcgui.Dialog()
    items = sorted(items, key=lambda e: (not e['now'], e['start'], e['channel']))
    while True:
        sel = dlg.select(title, [_entry_label(e) for e in items])
        if sel < 0:
            return 'back'
        if _entry_actions(items[sel]) == 'played':
            return 'played'


def _epg_entry_to_title(e):
    """Convert a short-horizon EPG entry into the title shape used by VodWindow."""
    start = e.get('start')
    end = e.get('end')
    try:
        start_e = int(start.timestamp()) if hasattr(start, 'timestamp') else int(start)
    except Exception:
        start_e = 0
    try:
        end_e = int(end.timestamp()) if hasattr(end, 'timestamp') else int(end)
    except Exception:
        end_e = start_e
    title = e.get('title') or '?'
    genre = e.get('genre') or ''
    return {
        'type': 'movie',  # display-only; recommendations are mixed content
        'title': title,
        'norm': title.lower(),
        'genre': genre,
        'plot': e.get('plot') or '',
        'plotoutline': '',
        'episodename': '',
        'episodenum': '',
        'firstaired': '',
        'year': None,
        'thumb': e.get('thumb') or '',
        'chicon': e.get('chicon') or '',
        'ch': e.get('channel') or '',
        'airings': [{
            'bid': e.get('broadcastid'),
            'cid': e.get('channelid'),
            'ch': e.get('channel') or '',
            'start': start_e,
            'end': end_e,
            'timer': bool(e.get('timer')),
            'thumb': e.get('thumb') or '',
            'episodename': '',
            'episodenum': '',
            'dt': start_e,
        }],
        'lib': {
            'poster': e.get('thumb') or '',
            'fanart': '',
            'rating': None,
            'plot': e.get('plot') or '',
            'ids': {},
        },
        '_rec_now': bool(e.get('now')),
        '_rec_entry': e,  # keep original for play / timer actions
    }


# ----------------------------------------------------------------------------
# Recommendation content filters (user preferences, offline)
# ----------------------------------------------------------------------------
def _entry_content_type(e):
    """Classify a short-horizon EPG entry: 'movie' | 'series' | None.

    Uses the same offline heuristics as the VOD catalogue (title markers,
    genre words, runtime) – no scrapers, no internet.
    """
    try:
        _vod = __import__('vod')
    except Exception:
        return None
    b = {
        'title': e.get('title') or '',
        'genre': e.get('genre') or '',
        'runtime': e.get('runtime') or 0,
        'episodename': '', 'episodenum': '', 'episodepart': '',
    }
    vtype, _genre = _vod.classify(b)
    if vtype is None:
        # Long, non-series broadcasts without a movie-like genre (news-free
        # backends) still deserve a spot as generic content.
        try:
            if int(b['runtime'] or 0) >= 85 and not _vod.looks_like_series(b, b['genre']):
                return 'movie'
        except Exception:
            pass
    return vtype


def _channels_icon_map():
    """channelid -> icon for the condensed-view rows."""
    icons = {}
    for c in get_channels('tv'):
        icons[c.get('channelid')] = c.get('icon') or ''
    return icons


def _collect_recordings(limit=50):
    """Recent TV recordings (offline, from the PVR backend)."""
    props = ['title', 'genre', 'plot', 'starttime', 'endtime',
             'recordingid', 'channelid', 'channelname', 'channelicon']
    r = jsonrpc('PVR.GetRecordings', {'properties': props})
    recs = r.get('recordings', []) if isinstance(r, dict) else []
    if not recs:
        r = jsonrpc('PVR.GetRecordings', {'properties': ['title', 'recordingid']})
        recs = r.get('recordings', []) if isinstance(r, dict) else []
    out = []
    for rec in recs[:limit]:
        try:
            st = to_local(rec['starttime'], False) if rec.get('starttime') else None
        except Exception:
            st = None
        out.append({
            '_kind': 'recording',
            'title': rec.get('title') or '?',
            'genre': rec.get('genre') or '',
            'plot': rec.get('plot') or '',
            'channel': rec.get('channelname') or rec.get('channel') or '',
            'channelid': rec.get('channelid'),
            'chicon': rec.get('channelicon') or '',
            'recordingid': rec.get('recordingid'),
            'start': int(st.timestamp()) if st is not None else 0,
            'end': 0,
            'thumb': '',
        })
    out.sort(key=lambda x: -x.get('start', 0))
    return out


def _detect_utc_quick():
    sample = []
    for ch in get_channels('tv')[:8]:
        sample.extend(get_broadcasts(ch['channelid'], 6))
        if sum(1 for b in sample if b.get('isactive')) >= 2:
            break
    return detect_utc(sample)


def _collect_planned():
    """Upcoming reminders + recording timers (the items the user planned)."""
    now = int(time.time())
    out = []
    for r in __import__('vod').pending_reminders():
        if r.get('start', 0) < now - 600:
            continue
        out.append({
            '_kind': 'reminder',
            'title': r.get('title') or '?',
            'genre': '',
            'plot': '',
            'channel': r.get('ch') or '',
            'channelid': r.get('cid'),
            'chicon': '',
            'broadcastid': r.get('bid'),
            'start': int(r.get('start') or 0),
            'end': int(r.get('end') or 0),
            'timer': True,
            'thumb': '',
        })
    utc_mode = _detect_utc_quick()
    for t in _get_timers():
        try:
            st = to_local(t['starttime'], utc_mode)
        except Exception:
            continue
        epoch = int(st.timestamp())
        if epoch < now - 60:
            continue
        out.append({
            '_kind': 'timer',
            'title': t.get('title') or '?',
            'genre': '',
            'plot': t.get('summary') or '',
            'channel': t.get('channelname') or '',
            'channelid': t.get('channelid'),
            'chicon': '',
            'start': epoch,
            'end': 0,
            'timer': True,
            'thumb': '',
        })
    out.sort(key=lambda x: x.get('start', 0))
    return out


def build_recommendation_entries(silent=True, with_genres=True):
    """Proposals for the 'Rekomendowane' view, filtered by user preferences.

    Returns (genre_entries, planned, recordings) – all JSON-safe (epochs).

    genre_entries: upcoming programmes from the guide, restricted to the
        content type chosen in settings (default: movies) and, when the
        preference filter is on, to genres the user actually watches
        (learned offline from viewing history).
    planned: reminders + recording timers added by the user.
    recordings: recent TV recordings.
    """
    planned, recs = [], []
    try:
        planned = _collect_planned()
    except Exception as e:
        log('planned collection failed: {}'.format(e), 'debug')
    try:
        recs = _collect_recordings()
    except Exception as e:
        log('recordings collection failed: {}'.format(e), 'debug')
    if not with_genres:
        return None, planned, recs

    horizon = max(1, Addon.setting_int('rec_horizon_hours', 6))
    entries = collect_epg(horizon, silent=silent)
    if entries is None:                    # cancelled progress dialog
        return None, planned, recs
    # JSON-safe copies (epoch times) – also used for the home-screen snapshot
    entries = [{
        'channelid': e.get('channelid'),
        'channel': e.get('channel') or '',
        'chicon': e.get('chicon') or '',
        'title': e.get('title') or '?',
        'plot': e.get('plot') or '',
        'start': int(e['start'].timestamp()) if hasattr(e.get('start'), 'timestamp') else int(e.get('start') or 0),
        'end': int(e['end'].timestamp()) if hasattr(e.get('end'), 'timestamp') else int(e.get('end') or 0),
        'genre': e.get('genre') or '',
        'runtime': e.get('runtime') or 0,
        'now': bool(e.get('now')),
        'timer': bool(e.get('timer')),
        'broadcastid': e.get('broadcastid'),
        'thumb': e.get('thumb') or '',
    } for e in entries]

    content = (Addon.setting('rec_content', 'movies') or 'movies').strip().lower()
    if content not in ('movies', 'series', 'both'):
        content = 'movies'
    if content != 'both':
        typed = [e for e in entries if _entry_content_type(e) == ('movie' if content == 'movies' else 'series')]
        entries = typed or entries      # fallback: never show an empty view

    if Addon.setting_bool('rec_filter_prefs', True):
        history = load_state().get('genres', {}) if Addon.setting_bool('rec_use_history', True) else {}
        if history:
            fav = [e for e in entries
                   if e.get('genre') and history.get(e['genre'], 0) > 0]
            if fav:
                entries = fav
            # no match → keep the unfiltered list (better than an empty view)

    # planned/recordings rows get their channel icon when we can resolve it
    icons = _channels_icon_map()
    for e in planned + recs:
        if not e.get('chicon') and icons.get(e.get('channelid')):
            e['chicon'] = icons[e['channelid']]
    entries.sort(key=lambda x: x.get('start', 0))
    return entries, planned, recs


def _rec_title_from_entry(e, genre_label):
    """Window title dict for planned/recording entries (epoch based)."""
    t = _epg_entry_to_title(e)
    t['genre'] = genre_label
    t['_rec_entry'] = e
    return t


def rec_entry_actions(e):
    """Action dialog for one condensed-view / recommendation entry.

    Returns 'played' when playback started (the window may close).
    """
    kind = e.get('_kind')
    if kind == 'recording':
        return _recording_actions(e)
    if kind == 'timer':
        return _timer_actions(e)
    e2 = dict(e)
    if isinstance(e2.get('start'), (int, float)):
        e2['start'] = datetime.fromtimestamp(int(e2['start']))
        end = e2.get('end')
        e2['end'] = datetime.fromtimestamp(int(end)) if end else e2['start']
    return _entry_actions(e2)


def _recording_actions(rec):
    dlg = xbmcgui.Dialog()
    head = '{}{}'.format(rec.get('title') or '?',
                         ' - {}'.format(rec['channel']) if rec.get('channel') else '')
    opts = [Addon.L(32412), Addon.L(32118), Addon.L(32119)]
    sel = dlg.select(head, opts)
    if sel == 0:
        if rec.get('recordingid'):
            jsonrpc('Player.Open', {'item': {'recordingid': int(rec['recordingid'])}})
            return 'played'
    elif sel == 1:
        dlg.textviewer(head, rec.get('plot') or Addon.L(32122))
    return 'back'


def _timer_actions(timer):
    dlg = xbmcgui.Dialog()
    head = '{} ({})'.format(timer.get('title') or '?',
                            timer.get('channel') or '?')
    opts = [Addon.L(32116), Addon.L(32322), Addon.L(32323), Addon.L(32119)]
    sel = dlg.select(head, opts)
    if sel == 0:
        if timer.get('channelid'):
            play_channel(timer['channelid'])
            return 'played'
    elif sel == 1:
        if timer.get('timerid') is not None:
            ok = bool(jsonrpc('PVR.DeleteTimer', {'timerid': int(timer['timerid'])}))
            dlg.notification(Addon.L(32308), Addon.L(32324 if ok else 32331), time=3000)
            if ok:
                update_home_widgets(force_scan=False)
    elif sel == 2:
        dlg.textviewer(head, timer.get('plot') or Addon.L(32122))
    return 'back'


def show_recommendations():
    """Recommendations as a full poster/grid window (same layout as VOD).

    Content comes from the settings: proposals filtered by the user's
    preferences (genres learned from viewing history), default movies,
    shown as a summary of upcoming programmes from the observed genres,
    items added to planning and recordings.
    """
    if xbmcgui is None:
        return
    if not is_pvr_ready():
        xbmcgui.Dialog().ok(Addon.L(32101), Addon.L(32103))
        return
    entries, planned, recs = build_recommendation_entries(silent=False,
                                                          with_genres=True)
    if entries is None:
        return
    if not entries and not planned and not recs:
        xbmcgui.Dialog().ok(Addon.L(32101), Addon.L(32103))
        return

    min_items = max(1, Addon.setting_int('rec_min_items', 1))
    history = load_state().get('genres', {}) if Addon.setting_bool('rec_use_history', True) else {}

    # Snapshot for the home-screen condensed view (fresh scan available)
    save_rec_snapshot({'built': int(time.time()), 'genres': entries,
                       'planned': planned, 'recordings': recs})

    titles = []
    # "For you" and "On air now" named buckets at the top of the filter
    fav_items = [e for e in entries
                 if e.get('genre') and history.get(e['genre'], 0) > 0]
    now_items = [e for e in entries if e.get('now')]
    if fav_items:
        for e in fav_items:
            t = _epg_entry_to_title(e)
            t['genre'] = Addon.L(32110)
            titles.append(t)
    if now_items:
        for e in now_items:
            t = _epg_entry_to_title(e)
            t['genre'] = Addon.L(32111)
            titles.append(t)

    by_genre = {}
    for e in entries:
        by_genre.setdefault(e.get('genre') or '', []).append(e)
    by_genre = {g: v for g, v in by_genre.items() if len(v) >= min_items}

    def rank(g):
        return (-(history.get(g, 0) if g else 0), g == '', -len(by_genre[g]), g)

    for g in sorted(by_genre, key=rank):
        for e in by_genre[g]:
            titles.append(_epg_entry_to_title(e))

    # Summary of what the user planned (reminders + timers) and recorded
    if planned and Addon.setting_bool('rec_show_planned', True):
        for e in planned:
            titles.append(_rec_title_from_entry(e, Addon.L(32381)))
    if recs and Addon.setting_bool('rec_show_recordings', True):
        for e in recs[:10]:
            titles.append(_rec_title_from_entry(e, Addon.L(32382)))

    if not titles:
        xbmcgui.Dialog().ok(Addon.L(32101), Addon.L(32123))
        return

    content = (Addon.setting('rec_content', 'movies') or 'movies').strip().lower()
    vtype = 'series' if content == 'series' else 'movie'
    data = {
        'days': 0,
        'movies': titles,   # all shown under the "movies" slot of the window
        'series': [],
        'mode': 'recommendations',
    }
    import vod_window
    vod_window.open_vod(vtype, force=False, preloaded=data)
    # The user may have added reminders/timers/recordings in the window
    update_home_widgets(force_scan=False)


# ----------------------------------------------------------------------------
# Home screen condensed views ("zakładki" previews, written as properties)
# ----------------------------------------------------------------------------
REC_SNAPSHOT_FILE = STATE_DIR + 'rec_snapshot.json'

WIDGET_ROWS = {
    'AntenaRec.G': 3,    # upcoming from the observed genres
    'AntenaRec.P': 2,    # planned (reminders + timers)
    'AntenaRec.R': 2,    # recordings
    'AntenaMovies': 4,   # upcoming movies
    'AntenaSeries': 4,   # upcoming series
}


def widget_interval_seconds():
    return max(5, Addon.setting_int('widget_refresh_minutes', 30)) * 60


def load_rec_snapshot():
    try:
        if xbmcvfs is None:
            import os
            path = os.path.expanduser('~/.antena-companion/rec_snapshot.json')
            if os.path.exists(path):
                return json.load(open(path))
            return None
        if xbmcvfs.exists(REC_SNAPSHOT_FILE):
            f = xbmcvfs.File(REC_SNAPSHOT_FILE)
            raw = f.read()
            f.close()
            return json.loads(raw) if raw else None
    except Exception as e:
        log('rec snapshot load failed: {}'.format(e), 'debug')
    return None


def save_rec_snapshot(snap):
    try:
        raw = json.dumps(snap, ensure_ascii=False)
        if xbmcvfs is None:
            import os
            os.makedirs(os.path.expanduser('~/.antena-companion'), exist_ok=True)
            open(os.path.expanduser('~/.antena-companion/rec_snapshot.json'), 'w').write(raw)
            return
        if not xbmcvfs.exists(STATE_DIR):
            xbmcvfs.mkdirs(STATE_DIR)
        f = xbmcvfs.File(REC_SNAPSHOT_FILE, 'w')
        f.write(raw)
        f.close()
    except Exception as e:
        log('rec snapshot save failed: {}'.format(e), 'error')


def _widget_row(win, prefix, n, item):
    """Write one condensed-view row: Title / Sub / Icon properties."""
    base = '{}.{}'.format(prefix, n)
    if not item:
        win.setProperty(base + '.Title', '')
        win.setProperty(base + '.Sub', '')
        win.setProperty(base + '.Icon', '')
        return
    win.setProperty(base + '.Title', item.get('title') or '')
    win.setProperty(base + '.Sub', item.get('sub') or '')
    win.setProperty(base + '.Icon', item.get('icon') or '')


def _when_sub(e):
    """'today 20:00 • Channel' for a condensed-view row."""
    start = int(e.get('start') or 0)
    hh = datetime.fromtimestamp(start).strftime('%H:%M') if start else ''
    ch = e.get('channel') or e.get('ch') or ''
    mark = ' \u23fa' if e.get('timer') else ''
    sub = '{} {}'.format(day_name(start), hh) if start else ''
    if ch:
        sub = '{} \u2022 {}'.format(sub, ch) if sub else ch
    return (sub + mark).strip()


def update_home_widgets(force_scan=False):
    """Write the condensed views shown when hovering the home-screen tabs.

    Focus on a menu category shows this preview immediately – no need to
    enter the view. Everything is written as Home window properties by the
    companion service; the skin only reads them (fully offline).
    """
    if xbmcgui is None:
        return
    try:
        win = xbmcgui.Window(10000)
    except Exception as e:
        log('home window unavailable: {}'.format(e), 'debug')
        return
    now = int(time.time())

    # Planned + recordings are cheap (two RPCs) – always fresh.
    planned, recs = [], []
    try:
        _, planned, recs = build_recommendation_entries(silent=True,
                                                        with_genres=False)
    except Exception as e:
        log('widget planned/recordings failed: {}'.format(e), 'debug')

    # Upcoming-from-genres rows come from the last snapshot; rescan only
    # when it is older than the refresh interval and a scan is allowed.
    snap = load_rec_snapshot()
    g_rows = (snap or {}).get('genres') or []
    snap_fresh = bool(snap) and now - int(snap.get('built') or 0) < widget_interval_seconds() + 60
    if (force_scan and not snap_fresh) or not g_rows:
        try:
            entries, planned2, recs2 = build_recommendation_entries(
                silent=True, with_genres=True)
            if entries is not None:
                planned, recs = planned2, recs2
                snap = {'built': now, 'genres': entries,
                        'planned': planned2, 'recordings': recs2}
                save_rec_snapshot(snap)
                g_rows = entries
        except Exception as e:
            log('widget scan failed: {}'.format(e), 'debug')

    history = load_state().get('genres', {}) if Addon.setting_bool('rec_use_history', True) else {}
    if xbmc is not None:
        try:
            win.setProperty('AntenaRec.Header', Addon.L(32383))
            win.setProperty('AntenaRec.H.G',
                            Addon.L(32380) if (history and Addon.setting_bool('rec_filter_prefs', True))
                            else Addon.L(32383))
            win.setProperty('AntenaRec.H.P', Addon.L(32381))
            win.setProperty('AntenaRec.H.R', Addon.L(32382))
        except Exception:
            pass

    n_rows = 0
    for i, e in enumerate(g_rows[:WIDGET_ROWS['AntenaRec.G']]):
        _widget_row(win, 'AntenaRec.G', i + 1, {
            'title': e.get('title') or '',
            'sub': _when_sub(e),
            'icon': e.get('thumb') or e.get('chicon') or '',
        })
        n_rows += 1
    for n in range(len(g_rows[:WIDGET_ROWS['AntenaRec.G']]) + 1,
                   WIDGET_ROWS['AntenaRec.G'] + 1):
        _widget_row(win, 'AntenaRec.G', n, None)
    for i, e in enumerate(planned[:WIDGET_ROWS['AntenaRec.P']]):
        _widget_row(win, 'AntenaRec.P', i + 1, {
            'title': e.get('title') or '',
            'sub': _when_sub(e),
            'icon': e.get('chicon') or '',
        })
        n_rows += 1
    for n in range(len(planned[:WIDGET_ROWS['AntenaRec.P']]) + 1,
                   WIDGET_ROWS['AntenaRec.P'] + 1):
        _widget_row(win, 'AntenaRec.P', n, None)
    for i, e in enumerate(recs[:WIDGET_ROWS['AntenaRec.R']]):
        start = int(e.get('start') or 0)
        date_txt = datetime.fromtimestamp(start).strftime('%d.%m %H:%M') if start else ''
        _widget_row(win, 'AntenaRec.R', i + 1, {
            'title': e.get('title') or '',
            'sub': '{} \u2022 {}'.format(date_txt, e.get('channel') or '') if e.get('channel') else date_txt,
            'icon': e.get('thumb') or e.get('chicon') or '',
        })
        n_rows += 1
    for n in range(len(recs[:WIDGET_ROWS['AntenaRec.R']]) + 1,
                   WIDGET_ROWS['AntenaRec.R'] + 1):
        _widget_row(win, 'AntenaRec.R', n, None)
    win.setProperty('AntenaRec.Count', str(n_rows))

    # Movies / series condensed views from the cached catalogue
    try:
        _vod = __import__('vod')
        cache = _vod.load_cache_any()
    except Exception:
        cache = None
    for prefix, key, header_id in (('AntenaMovies', 'movies', 32384),
                                   ('AntenaSeries', 'series', 32385)):
        try:
            win.setProperty(prefix + '.Header', Addon.L(header_id))
        except Exception:
            pass
        items = (cache or {}).get(key) or []
        n = 0
        for t in items[:WIDGET_ROWS[prefix]]:
            a0 = (t.get('airings') or [{}])[0]
            start = int(a0.get('start') or 0)
            label = t.get('title') or '?'
            lib = t.get('lib') or {}
            year = lib.get('year') or t.get('year')
            if year:
                label = '{} ({})'.format(label, year)
            hh = datetime.fromtimestamp(start).strftime('%H:%M') if start else ''
            sub = '{} {}'.format(day_name(start), hh) if start else ''
            if a0.get('ch'):
                sub = '{} \u2022 {}'.format(sub, a0['ch']) if sub else a0['ch']
            icon = lib.get('poster') or t.get('thumb') or t.get('chicon') or ''
            _widget_row(win, prefix, n + 1, {'title': label, 'sub': sub, 'icon': icon})
            n += 1
        for k in range(n + 1, WIDGET_ROWS[prefix] + 1):
            _widget_row(win, prefix, k, None)
        win.setProperty(prefix + '.Count', str(n))


def maybe_build_catalogue_background():
    """Warm the movies/series catalogue cache so the windows open instantly."""
    if not Addon.setting_bool('widget_build_catalogue', True):
        return
    if xbmc is None:
        return
    try:
        _vod = __import__('vod')
        days = max(1, Addon.setting_int('vod_days', 7))
        ttl = max(1, Addon.setting_int('vod_cache_minutes', 30))
        if _vod.load_cache(days, ttl) is not None:
            return                        # cache still fresh
        log('building VOD catalogue in background', 'info')
        data = _vod.build_catalogue(days, Addon.setting_bool('vod_use_library', False), None)
        if data is not None:
            _vod.save_cache(data)
    except Exception as e:
        log('background catalogue build failed: {}'.format(e), 'debug')


def rec_open(section='G', index=1):
    """Action dialog for one row of the home-screen condensed views.

    RunScript(script.antena.companion,rec_open,<G|P|R>,<1..n>)
    """
    snap = load_rec_snapshot() or {}
    key = {'G': 'genres', 'P': 'planned', 'R': 'recordings'}.get(section, 'genres')
    rows = snap.get(key) or []
    try:
        idx = int(index)
    except (TypeError, ValueError):
        idx = 1
    e = rows[idx - 1] if 1 <= idx <= len(rows) else None
    if e is None:
        show_recommendations()
        return
    rec_entry_actions(e)


# ----------------------------------------------------------------------------
# Service
# ----------------------------------------------------------------------------
class ServiceMonitor(xbmc.Monitor if xbmc is not None else object):
    def __init__(self):
        if xbmc is not None:
            super().__init__()
        self.state = load_state()
        self.did_autostart = False
        self.last_attempt = 0

    def onNotification(self, sender, method, data):
        if method != 'Player.OnAVStarted':
            return
        try:
            d = json.loads(data) if isinstance(data, str) else data
            item = d.get('item', {})
            if item.get('type') != 'channel':
                return
            pid = (d.get('player') or {}).get('playerid', 1)
            r = jsonrpc('Player.GetItem', {'playerid': pid,
                                           'properties': ['channel', 'channelid', 'channeltype']})
            it = r.get('item', {}) if isinstance(r, dict) else {}
            cid = it.get('channelid') or item.get('id')
            if not cid:
                return
            self.state['last_channel_id'] = cid
            self.state['last_channel_name'] = it.get('channel') or it.get('label') or ''
            self.state['last_channel_type'] = it.get('channeltype') or 'tv'
            self.state['last_played_at'] = int(time.time())
            self._learn_genre(cid)
            save_state(self.state)
            log('Remembered channel {} ({})'.format(cid, self.state['last_channel_name']), 'info')
        except Exception as e:
            log('onNotification failed: {}'.format(e), 'error')

    def _learn_genre(self, channel_id):
        for b in get_broadcasts(channel_id, 6):
            if b.get('isactive'):
                g = genre_of(b)
                if g:
                    gen = self.state.setdefault('genres', {})
                    gen[g] = gen.get(g, 0) + 1
                    if sum(gen.values()) > 300:
                        for k in list(gen):
                            gen[k] = gen[k] // 2
                            if gen[k] <= 0:
                                del gen[k]
                break

    def try_autostart(self):
        if self.did_autostart or not Addon.setting_bool('autostart_last_channel', True):
            return
        last_id = self.state.get('last_channel_id')
        if not last_id:
            self.did_autostart = True
            return
        if not is_pvr_ready():
            return
        delay = max(Addon.setting_int('autostart_delay_seconds', 5), 1)
        if time.time() - self.last_attempt < delay:
            return
        self.last_attempt = time.time()
        pref = Addon.setting('autostart_channel_type', 'tv') or 'tv'
        last_type = self.state.get('last_channel_type') or 'tv'
        if pref != 'both' and pref != last_type:
            self.did_autostart = True
            return
        log('Autostart: channel {}'.format(last_id), 'info')
        play_channel(last_id)
        self.did_autostart = True

    def run(self):
        if xbmc is None:
            return
        log('Service started', 'info')
        while not self.abortRequested():
            self.try_autostart()
            if self.waitForAbort(1):
                break
        log('Service stopped', 'info')


# ----------------------------------------------------------------------------
# VOD / planning helpers (lazy imports: vod imports this module)
# ----------------------------------------------------------------------------
def _fmt_airing(a):
    """Compact label for one airing: 'today 20:00 • TVN'."""
    day = day_name(a.get('start', 0))
    hh = datetime.fromtimestamp(a.get('start', 0)).strftime('%H:%M')
    mark = ' \u23fa' if a.get('timer') else ''
    return '{} {} \u2022 {}{}'.format(day, hh, a.get('ch') or '?', mark)


def _pick_lead_minutes():
    """Reminder lead-time picker (1/5/10/30/60 min, default from settings)."""
    dflt = max(1, Addon.setting_int('vod_remind_default', 10))
    opts = [1, 5, 10, 30, 60]
    labels = ['{} min{}'.format(m, ' ' + Addon.L(32328) if m == dflt else '') for m in opts]
    sel = xbmcgui.Dialog().select(Addon.L(32312), labels)
    if sel < 0:
        return None
    return opts[sel]


def _add_timer(broadcastid, timerrule=False):
    """PVR.AddTimer; timerrule=True asks the backend for a series rule."""
    params = {'broadcastid': int(broadcastid)}
    if timerrule:
        params['timerrule'] = True
    return bool(jsonrpc('PVR.AddTimer', params))


def show_title_actions(t):
    """Action dialog for one title from the TV guide view. Returns 'close'
    when the user starts playback (so the window may close)."""
    import vod as _vod
    dlg = xbmcgui.Dialog()
    airings = t.get('airings') or []
    a0 = airings[0] if airings else {}
    lib = t.get('lib') or {}
    while True:
        opts = [Addon.L(32116), Addon.L(32117)]
        if t.get('type') == 'series':
            opts.append(Addon.L(32311))
        opts += [Addon.L(32312),
                 Addon.L(32313) + '  ({})'.format(len(airings)),
                 Addon.L(32118)]
        opts.append(Addon.L(32119))
        sel = dlg.select(t['title'], opts)
        if sel < 0:
            return None
        label = opts[sel]
        if label == Addon.L(32116):
            if a0.get('cid'):
                play_channel(a0['cid'])
                return 'close'
        elif label == Addon.L(32117):
            if a0.get('bid'):
                ok = _add_timer(a0['bid'])
                dlg.notification(Addon.L(32101), Addon.L(32120 if ok else 32121), time=3000)
        elif label == Addon.L(32311):
            if a0.get('bid'):
                ok = _add_timer(a0['bid'], timerrule=True)
                dlg.notification(Addon.L(32340),
                                 Addon.L(32314 if ok else 32315), time=4000)
        elif label == Addon.L(32312):
            lead = _pick_lead_minutes()
            if lead:
                _vod.add_reminder(t, a0, lead)
                dlg.notification(Addon.L(32318), Addon.L(32316), time=3000)
        elif label.startswith(Addon.L(32313)):
            _show_airings(t)
        elif label == Addon.L(32118):
            meta = []
            r = (lib.get('rating') or 0)
            try:
                if r:
                    meta.append('\u2605 {:.1f}'.format(float(r)))
            except Exception:
                pass
            if lib.get('year'):
                meta.append(str(lib['year']))
            if t.get('genre'):
                meta.append(t['genre'])
            head = t['title'] + ('  ({})'.format(' \u00b7 '.join(meta)) if meta else '')
            dlg.textviewer(head, lib.get('plot') or t.get('plot') or Addon.L(32122))
        else:
            return None


def _show_airings(t):
    dlg = xbmcgui.Dialog()
    airings = sorted(t.get('airings') or [], key=lambda a: a.get('start', 0))
    while True:
        sel = dlg.select(t['title'], [_fmt_airing(a) for a in airings])
        if sel < 0:
            return
        a = airings[sel]
        opts = [Addon.L(32117), Addon.L(32312), Addon.L(32119)]
        s2 = dlg.select(_fmt_airing(a), opts)
        if s2 == 0 and a.get('bid'):
            ok = _add_timer(a['bid'])
            dlg.notification(Addon.L(32101), Addon.L(32120 if ok else 32121), time=3000)
        elif s2 == 1:
            lead = _pick_lead_minutes()
            if lead:
                import vod as _vod
                _vod.add_reminder(t, a, lead)
                dlg.notification(Addon.L(32318), Addon.L(32316), time=3000)


TIMER_PROPS_EXT = ['title', 'starttime', 'endtime', 'summary', 'state',
                   'timerid', 'channelname', 'channelid']
TIMER_PROPS_BASE = ['title', 'starttime', 'endtime', 'summary', 'state', 'timerid']


def _get_timers():
    params = {'properties': TIMER_PROPS_EXT, 'limits': {'start': 0, 'end': 500}}
    r, err = __import__('vod').jsonrpc_full('PVR.GetTimers', params)
    if err is not None:
        r, _ = __import__('vod').jsonrpc_full(
            'PVR.GetTimers', {'properties': TIMER_PROPS_BASE,
                              'limits': {'start': 0, 'end': 500}})
    return r.get('timers') or [] if isinstance(r, dict) else []


def show_planning():
    """Planning manager: upcoming reminders + recording timers."""
    import vod as _vod
    if xbmcgui is None:
        return
    dlg = xbmcgui.Dialog()
    now = int(time.time())
    sample = []
    chans = get_channels('tv')
    for ch in chans[:8]:
        sample.extend(get_broadcasts(ch['channelid'], 6))
        if sum(1 for b in sample if b.get('isactive')) >= 2:
            break
    utc_mode = detect_utc(sample)

    entries = []   # (sort_key, kind, payload)
    for r in _vod.pending_reminders():
        if r.get('start', 0) < now - 600:
            continue
        entries.append((r['start'], 'rem', r))
    timers = []
    for t in _get_timers():
        try:
            st = to_local(t['starttime'], utc_mode)
        except Exception:
            continue
        epoch = int(st.timestamp())
        if epoch < now - 60:
            continue
        t['_epoch'] = epoch
        timers.append(t)
        entries.append((epoch, 'tim', t))
    if not entries:
        dlg.ok(Addon.L(32308), Addon.L(32320))
        return
    entries.sort(key=lambda e: e[0])

    while True:
        items = []
        for _, kind, p in entries:
            if kind == 'rem':
                left = max(0, (p['start'] - now) // 60)
                left_txt = Addon.L(32114) if left == 0 else '{} min'.format(left)
                items.append('\u23f0 {} \u2022 {} (za {})'.format(
                    _fmt_airing(p), p.get('title') or '?', left_txt))
            else:
                items.append('\u23fa {} \u2022 {}'.format(
                    _fmt_airing({'start': p['_epoch'],
                                 'ch': p.get('channelname') or '',
                                 'timer': True}),
                    p.get('title') or '?'))
        sel = dlg.select(Addon.L(32308), items)
        if sel < 0:
            return
        _, kind, p = entries[sel]
        if kind == 'rem':
            opts = [Addon.L(32321), Addon.L(32323), Addon.L(32119)]
            s2 = dlg.select(p.get('title') or '?', opts)
            if s2 == 0:
                _vod.cancel_reminder(p.get('key'))
                entries = [e for e in entries if not (e[1] == 'rem'
                                                      and e[2].get('key') == p.get('key'))]
                dlg.notification(Addon.L(32318), Addon.L(32317), time=3000)
                if not entries:
                    dlg.ok(Addon.L(32308), Addon.L(32320))
                    return
            elif s2 == 1:
                when = datetime.fromtimestamp(p.get('start', 0)).strftime('%d.%m %H:%M')
                dlg.textviewer(p.get('title') or '?',
                               '{} \u2022 {} \u2022 {} {} min'.format(
                                   when, p.get('ch') or '?', Addon.L(32312), p.get('lead', 10)))
        else:
            opts = [Addon.L(32322), Addon.L(32323), Addon.L(32119)]
            s2 = dlg.select(p.get('title') or '?', opts)
            if s2 == 0:
                ok = bool(jsonrpc('PVR.DeleteTimer', {'timerid': int(p.get('timerid'))}))
                dlg.notification(Addon.L(32308),
                                 Addon.L(32324 if ok else 32331), time=3000)
                if ok:
                    timers = [x for x in timers if x.get('timerid') != p.get('timerid')]
                    entries = [e for e in entries if not (e[1] == 'tim'
                                                          and e[2].get('timerid') == p.get('timerid'))]
                    if not entries:
                        dlg.ok(Addon.L(32308), Addon.L(32320))
                        return
            elif s2 == 1:
                dlg.textviewer(p.get('title') or '?',
                               p.get('summary') or Addon.L(32122))


def show_vod(vtype='movie', force=False):
    """Open the VOD poster-wall window (lazy import keeps the service light)."""
    import vod_window
    if xbmcgui is None:
        return
    if not is_pvr_ready():
        xbmcgui.Dialog().ok(Addon.L(32301), Addon.L(32103))
        return
    vod_window.open_vod(vtype, force=force)
    # The user may have added reminders/timers in the window
    update_home_widgets(force_scan=False)


def check_reminders_and_fire():
    """Service hook: fire due reminders as on-screen notifications."""
    try:
        import vod as _vod
        for title, ch, mins, start in _vod.check_reminders(fire=True):
            _vod.fire_notification(title, ch, mins, start)
    except Exception as e:
        log('reminders tick failed: {}'.format(e), 'error')


# ----------------------------------------------------------------------------
def main():
    args = sys.argv[1:]
    action = args[0] if args else 'recommendations'
    if action == 'autostart':
        cid = load_state().get('last_channel_id')
        if cid:
            play_channel(cid)
    elif action in ('vod', 'vod_movies'):
        show_vod('movie')
    elif action == 'vod_series':
        show_vod('series')
    elif action == 'plan':
        show_planning()
    elif action == 'rec_open':
        # Action dialog for one row of the home-screen condensed views
        rec_open(args[1] if len(args) > 1 else 'G',
                 args[2] if len(args) > 2 else 1)
    else:
        show_recommendations()


if __name__ == '__main__':
    main()
