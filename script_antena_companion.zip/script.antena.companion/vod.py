#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Antena Companion - TV guide catalogue engine ("Filmy w TV" / "Seriale w TV").

Builds an "upcoming" catalogue from the Kodi programme guide:

    * scans PVR.GetBroadcasts for every visible TV channel,
    * classifies each broadcast as a movie or a series episode,
    * groups repeated broadcasts into titles with all their airings,
    * optionally enriches titles with data from the Kodi video library
      (ratings, posters - data written there by library scrapers; OFF by
      default because those scrapers need internet),
    * caches the scan so the window opens instantly.

Reminders are also handled here: they live in the addon state file and
are fired by the background service (check_reminders()).
"""

import json
import re
import time
import unicodedata
import hashlib
from datetime import datetime, timedelta

try:
    import xbmc
    import xbmcgui
    import xbmcaddon
    import xbmcvfs
except ImportError:  # allow tests outside Kodi
    xbmc = xbmcgui = xbmcaddon = xbmcvfs = None

import default

ADDON_ID = default.ADDON_ID
STATE_DIR = default.STATE_DIR
CACHE_FILE = STATE_DIR + 'vod_cache.json'

# ---------------------------------------------------------------------------
# Broadcast properties
# ---------------------------------------------------------------------------
# Minimal set proven to work with pvr.hts (same as recommendations).
# Anything beyond this is requested only as a best-effort enrichment.
SAFE_BROADCAST_PROPS = [
    'title', 'plot', 'starttime', 'endtime', 'runtime',
    'genre', 'hastimer', 'isactive', 'wasactive',
]
# Common extra fields – tried only after SAFE succeeds.
EXTRA_BROADCAST_PROPS = SAFE_BROADCAST_PROPS + [
    'plotoutline', 'episodename', 'episodenum', 'episodepart', 'firstaired',
    'rating', 'thumbnail', 'broadcastid', 'progress', 'progresspercentage',
    'year', 'originaltitle', 'epgeventid', 'timerid', 'image', 'epgid',
]
# Kept for older call sites / docs
BASE_BROADCAST_PROPS = SAFE_BROADCAST_PROPS
EXT_BROADCAST_PROPS = EXTRA_BROADCAST_PROPS

CHANNEL_PROPS = ['channel', 'channeltype', 'hidden', 'locked']
# 'icon' is optional – some backends reject unknown channel properties.
CHANNEL_PROPS_WITH_ICON = CHANNEL_PROPS + ['icon']

LIB_MOVIE_PROPS = ['title', 'year', 'uniqueid', 'rating', 'art', 'plot', 'genre', 'trailer']
LIB_EPISODE_PROPS = ['title', 'showtitle', 'season', 'episode', 'uniqueid', 'rating', 'art', 'plot']
LIB_SHOW_PROPS = ['title', 'uniqueid', 'rating', 'art']

# Classification keywords (case-insensitive substrings).
SERIES_GENRE_WORDS = (
    'serial', 'series', 'sitcom', 'telenovela', 'telenowela', 'soap opera',
    'serie', 'comedie en serie', 'seria animowana', 'miniserial', 'mini-series',
    'drama series', 'comedy series',
)
# Explicit movie markers in genre string.
MOVIE_GENRE_WORDS = (
    'film', 'movie', 'kino', 'cinema', 'bajka film', 'feature', 'filmy',
)
# Genres typical for theatrical/TV movies (used only with long runtime).
MOVIE_LIKE_GENRES = (
    'dramat', 'drama', 'komedia', 'comedy', 'thriller', 'horror', 'akcja',
    'action', 'krymina', 'crime', 'western', 'fantasy', 'science fiction',
    'sci-fi', 'scifi', 'romans', 'romance', 'przygod', 'adventure',
    'animacj', 'animation', 'familijn', 'family', 'wojenny', 'war',
    'historycz', 'historical', 'muzyczny', 'musical', 'dokumentalny film',
    'dreszczowiec', 'sensacj', 'erotycz',
)
# Hard exclude from VOD movies/series (news, magazines, sport, etc.).
NON_VOD_GENRE_WORDS = (
    'magazyn', 'informacyj', 'wiadomo', 'news', 'aktualno', 'pogoda',
    'weather', 'sport', 'piłka', 'mecz', 'football', 'edukac', 'nauka',
    'na faktach', 'religij', 'msza', 'nabożeńst', 'reklama', 'teleshop',
    'telegazet', 'program o', 'talk-show', 'talk show', 'reality',
    'kulinar', 'gotowa', 'lifestyle', 'poradnik', 'interwenc',
    'publicyst', 'debat', 'wywiad', 'reportaż', 'reportaz',
)

SERIES_TITLE_RE = re.compile(
    r'(\bs\d{1,2}[\s._-]?e\d{1,3}\b|\bodc(in(ek|ka)?)?\b|\bodcinek\b|\bsezon\b'
    r'|\bseason\b|\bepisode\b|\bepizod\b|\bcz\.\s*\d|\bpart\s*\d)', re.IGNORECASE)

SERIES_TITLE_STRIP_RES = [
    re.compile(r'\s*[-\-–—:,]\s*(odc|sezon|season|episode|epizod|s\d{1,2}).*$', re.IGNORECASE),
    re.compile(r'\s+\bodc.*$', re.IGNORECASE),
    re.compile(r'\s*\bs\d{1,2}[\s._-]?e\d{1,3}\b.*$', re.IGNORECASE),
    re.compile(r'\s+\(\s*(odc|sezon|season).*$', re.IGNORECASE),
]

TAG_BRACKET_RE = re.compile(r'\[[^\]]*\]|\([^)]*\b(19|20)\d{2}\s*\)')


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------
def log(msg, level='info'):
    default.log(msg, level)


def normalize_title(s):
    """Normalize a title for matching: lowercase, strip diacritics,
    punctuation, common quality tags and the leading article."""
    if not s:
        return ''
    s = s.lower()
    s = unicodedata.normalize('NFKD', s)
    s = ''.join(c for c in s if not unicodedata.combining(c))
    s = TAG_BRACKET_RE.sub(' ', s)
    s = re.sub(r'[^\w\s]', ' ', s)
    s = re.sub(r'\b(the|le|la|a|an)\b', ' ', s)
    s = re.sub(r'\s+', ' ', s).strip()
    return s


def clean_genre(g):
    g = (g or '').strip()
    if not g:
        return ''
    return g[0].upper() + g[1:]


def first_genre(b):
    g = b.get('genre') or []
    if isinstance(g, str):
        g = [g]
    g = [x.strip() for x in g if x and x.strip()]
    return g[0] if g else ''


def extract_series_title(title):
    """'Kroniki Młodego Eksperta: odc. 4' -> 'Kroniki Młodego Eksperta'."""
    t = title or ''
    for rx in SERIES_TITLE_STRIP_RES:
        t2 = rx.sub('', t)
        if t2.strip():
            t = t2.strip()
    return t.strip(' ,-–—:')


def _genre_has(words, genre):
    g = (genre or '').lower()
    for w in words:
        if w and w.lower() in g:
            return True
    return False


def is_non_vod_genre(genre):
    """News / magazine / sport / religion etc. – never show in VOD."""
    return _genre_has(NON_VOD_GENRE_WORDS, genre)


def looks_like_series(b, genre=''):
    """Heuristic classification: does this broadcast look like a series?"""
    if is_non_vod_genre(genre):
        return False
    if b.get('episodename') or b.get('episodenum') or b.get('episodepart'):
        return True
    title = b.get('title') or ''
    if SERIES_TITLE_RE.search(title):
        return True
    if _genre_has(SERIES_GENRE_WORDS, genre):
        return True
    return False


def looks_like_movie(b, genre=''):
    """True only for real films – not magazines, news, short fillers."""
    if is_non_vod_genre(genre):
        return False
    if _genre_has(MOVIE_GENRE_WORDS, genre):
        return True
    # Long runtime + movie-like genre (e.g. "Dramat", "Kryminał") → movie
    try:
        runtime = int(b.get('runtime') or 0)
    except (TypeError, ValueError):
        runtime = 0
    if runtime >= 70 and _genre_has(MOVIE_LIKE_GENRES, genre):
        return True
    # Very long runtime with no series markers → treat as movie
    if runtime >= 85 and not looks_like_series(b, genre):
        return True
    return False


def classify(b):
    """Return ('movie'|'series'|None, cleaned_genre).

    None = skip for VOD (not a film or series episode).
    """
    genre = clean_genre(first_genre(b))
    if is_non_vod_genre(genre):
        return None, genre
    if looks_like_series(b, genre):
        return 'series', genre
    if looks_like_movie(b, genre):
        return 'movie', genre
    return None, genre


def ui_language():
    """'pl' when the UI language is Polish, else 'en' (for plural rules)."""
    if xbmc is None:
        return 'en'
    try:
        lang = (xbmc.getInfoLabel('System.Language') or '').lower()
        if 'pol' in lang or 'polsk' in lang:
            return 'pl'
    except Exception:
        pass
    return 'en'


def airings_noun(n):
    """Localized noun for airing counts: 32305 = airing/emisja,
    32306 = airings/emisje, 32307 = airings/emisji."""
    n = int(n)
    if ui_language() == 'pl':
        if n == 1:
            return default.Addon.L(32305)
        if 2 <= n % 10 <= 4 and not 12 <= n % 100 <= 14:
            return default.Addon.L(32306)
        return default.Addon.L(32307)
    return default.Addon.L(32305) if n == 1 else default.Addon.L(32306)


def _parse_dt(s):
    return datetime.strptime(s, '%Y-%m-%d %H:%M:%S')


def epoch_of(dt):
    return int(time.mktime(dt.timetuple()))


# ---------------------------------------------------------------------------
# JSON-RPC helpers (reuse default.jsonrpc, add error visibility)
# ---------------------------------------------------------------------------
def jsonrpc_full(method, params=None):
    """Like default.jsonrpc but returns (result, error) so callers can
    fall back when a property is not supported by the PVR backend."""
    if xbmc is None:
        return {}, None
    payload = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params is not None:
        payload['params'] = params
    try:
        d = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
        if d.get('error'):
            return d.get('result') or {}, d.get('error')
        return d.get('result') or {}, None
    except Exception as e:
        log('jsonrpc {} failed: {}'.format(method, e), 'error')
        return {}, {'message': str(e)}


def get_broadcasts_vod(channel_id, count=200, start_index=0):
    """Full-guide broadcast list for a channel (pageable).

    Always starts with the same minimal property set that recommendations
    use successfully on pvr.hts. Only then tries richer fields.
    `start_index` allows paging through long days so no part of the day
    is ever skipped (short programmes used to cut the scan early).
    """
    sidx = max(0, int(start_index))
    eidx = sidx + max(1, int(count))
    params = {
        'channelid': int(channel_id),
        'properties': SAFE_BROADCAST_PROPS,
        'limits': {'start': sidx, 'end': eidx},
    }
    result, err = jsonrpc_full('PVR.GetBroadcasts', params)
    if err is not None:
        log('GetBroadcasts SAFE failed for ch {}: {}'.format(channel_id, err), 'debug')
        # Last resort: identical call to what recommendations use (count=12)
        params['limits'] = {'start': sidx, 'end': sidx + 12}
        result, err = jsonrpc_full('PVR.GetBroadcasts', params)
        if err is not None:
            log('GetBroadcasts fallback also failed for ch {}: {}'.format(
                channel_id, err), 'debug')
            return []
    broadcasts = result.get('broadcasts') or []
    # Optional enrichment with extra fields – never fail the whole channel.
    if broadcasts and count > 12:
        params['properties'] = EXTRA_BROADCAST_PROPS
        params['limits'] = {'start': sidx, 'end': eidx}
        result2, err2 = jsonrpc_full('PVR.GetBroadcasts', params)
        if err2 is None and result2.get('broadcasts'):
            broadcasts = result2['broadcasts']
    return broadcasts


def get_channels_vod(channel_type='tv'):
    # Prefer icon when the backend supports it; fall back to the same
    # property set recommendations use (known to work on pvr.hts).
    r = default.jsonrpc('PVR.GetChannels', {
        'channelgroupid': 'all' + channel_type,
        'properties': CHANNEL_PROPS_WITH_ICON})
    chans = r.get('channels', []) if isinstance(r, dict) else []
    if not chans:
        r = default.jsonrpc('PVR.GetChannels', {
            'channelgroupid': 'all' + channel_type,
            'properties': CHANNEL_PROPS})
        chans = r.get('channels', []) if isinstance(r, dict) else []
    return [c for c in chans if not c.get('hidden') and not c.get('locked')]


# ---------------------------------------------------------------------------
# Kodi video library (scraper-written metadata)
# ---------------------------------------------------------------------------
class LibraryMap:
    """Movie/episode/show indexes built from the Kodi video library."""

    def __init__(self):
        self.movies = {}     # norm title -> movie dict
        self.episodes = {}   # norm title -> episode dict
        self.shows = {}      # norm showtitle -> show dict
        self.loaded = False

    def load(self, force=False):
        if self.loaded and not force:
            return self
        self.movies, self.episodes, self.shows = {}, {}, {}
        movies = self._query('VideoLibrary.GetMovies', 'movies', LIB_MOVIE_PROPS)
        for m in movies or []:
            key = normalize_title(m.get('title'))
            if key and key not in self.movies:
                self.movies[key] = m
        # TV shows first: their art wins over the per-episode fallback
        shows = self._query('VideoLibrary.GetTVShows', 'tvshows', LIB_SHOW_PROPS)
        for s in shows or []:
            key = normalize_title(s.get('title'))
            if key and key not in self.shows:
                self.shows[key] = s
        episodes = self._query('VideoLibrary.GetEpisodes', 'episodes', LIB_EPISODE_PROPS)
        for e in episodes or []:
            key = normalize_title(e.get('title'))
            if key and key not in self.episodes:
                self.episodes[key] = e
            show_key = normalize_title(e.get('showtitle'))
            if show_key and show_key not in self.shows:
                self.shows[show_key] = {'title': e.get('showtitle'), 'art': e.get('art') or {}}
        self.loaded = True
        log('library map: {} movies, {} episodes, {} shows'.format(
            len(self.movies), len(self.episodes), len(self.shows)), 'info')
        return self

    @staticmethod
    def _query(method, result_key, props):
        r = default.jsonrpc(method, {
            'properties': props,
            'limits': {'start': 0, 'end': 20000}})
        return r.get(result_key) or [] if isinstance(r, dict) else []

    def match_movie(self, title, year=None):
        m = self.movies.get(normalize_title(title))
        if m is None:
            return None
        if year and m.get('year') and abs(int(m['year']) - int(year)) > 1:
            return None
        return m

    def match_episode(self, title, episodename=''):
        ep = self.episodes.get(normalize_title(episodename or ''))
        if ep is not None:
            return ep, self.shows.get(normalize_title(ep.get('showtitle')))
        ep = self.episodes.get(normalize_title(title))
        if ep is not None:
            return ep, self.shows.get(normalize_title(ep.get('showtitle')))
        # 'Show: episode name' / 'Show - episode name'
        m = re.match(r'^(.{2,60}?)\s*[:\-\u2013\u2014]\s*(.+)$', title or '')
        if m:
            ep = self.episodes.get(normalize_title(m.group(2)))
            if ep is not None and normalize_title(m.group(1)) == normalize_title(ep.get('showtitle') or ''):
                return ep, self.shows.get(normalize_title(m.group(1)))
        return None, None

    @staticmethod
    def extract(m_or_ep, is_show=False):
        """Flatten library info into the enrichment dict used by the VOD."""
        if not m_or_ep:
            return None
        art = m_or_ep.get('art') or {}
        uid = m_or_ep.get('uniqueid') or {}
        ids = {}
        if isinstance(uid, dict):
            for k, v in uid.items():
                if v:
                    ids[k.lower()] = v
        info = {
            'rating': m_or_ep.get('rating'),
            'ids': ids or None,
            'year': m_or_ep.get('year'),
            'poster': art.get('poster') or art.get('thumb') or None,
            'fanart': art.get('fanart') or None,
            'trailer': (m_or_ep.get('trailer') or None) if not is_show else None,
            'plot': m_or_ep.get('plot') or None,
        }
        if is_show:
            info['trailer'] = None
        return info


# ---------------------------------------------------------------------------
# Reminder store (state.json) + firing
# ---------------------------------------------------------------------------
def load_vod_state():
    return default.load_state()


def save_vod_state(st):
    default.save_state(st)


def reminder_key(entry, airing):
    bid = airing.get('bid')
    if bid:
        return 'b{}'.format(int(bid))
    raw = '{}|{}|{}'.format(entry.get('title'), airing.get('ch'), airing.get('start'))
    return 'h' + hashlib.md5(raw.encode('utf-8')).hexdigest()[:12]


def add_reminder(entry, airing, lead_minutes):
    """Store a reminder; replaces an existing one for the same airing."""
    st = load_vod_state()
    rem = st.setdefault('reminders', [])
    key = reminder_key(entry, airing)
    rem = [r for r in rem if r.get('key') != key]
    rem.append({
        'key': key,
        'bid': airing.get('bid'),
        'cid': airing.get('cid'),
        'ch': airing.get('ch'),
        'title': entry.get('title'),
        'start': int(airing.get('start') or 0),
        'end': int(airing.get('end') or 0),
        'lead': int(lead_minutes),
        'created': int(time.time()),
        'fired': False,
    })
    st['reminders'] = rem
    save_vod_state(st)
    log('reminder added: {} + {}min'.format(entry.get('title'), lead_minutes), 'info')


def cancel_reminder(key):
    st = load_vod_state()
    rem = [r for r in st.get('reminders', []) if r.get('key') != key]
    st['reminders'] = rem
    save_vod_state(st)
    return True


def pending_reminders():
    st = load_vod_state()
    return sorted([r for r in st.get('reminders', []) if not r.get('fired')],
                  key=lambda r: r.get('start', 0))


def check_reminders(fire=True):
    """Called by the service loop: return due reminders and (when fire=True)
    mark them as fired so they are shown only once. fire=False is a dry run.

    Returns list of (title, channel, minutes_left, start_epoch).
    """
    st = load_vod_state()
    rem = st.get('reminders', [])
    if not rem:
        return []
    now = int(time.time())
    fired = []
    changed = False
    for r in rem:
        if r.get('fired'):
            continue
        start = int(r.get('start') or 0)
        lead = max(0, int(r.get('lead') or 10))
        at = start - lead * 60
        if now >= at:
            if start + 600 > now:  # still relevant: up to 10 min past start
                fired.append((r.get('title') or '?', r.get('ch') or '',
                              max(0, (start - now) // 60), start))
            if fire:
                r['fired'] = True
                changed = True
    # cleanup: remove reminders for broadcasts finished > 2h ago
    keep = [r for r in rem if int(r.get('start') or 0) + 7200 > now]
    if len(keep) != len(rem) or changed:
        st['reminders'] = keep
        save_vod_state(st)
    return fired


def fire_notification(title, channel, minutes_left, start=None):
    if xbmcgui is None:
        print('[antena] reminder: {} on {} in {} min'.format(title, channel, minutes_left))
        return
    mins_txt = default.Addon.L(32114) if minutes_left <= 0 else '{} min'.format(minutes_left)
    time_txt = ''
    if start:
        from datetime import datetime as _dt
        time_txt = _dt.fromtimestamp(int(start)).strftime('%H:%M')
    msg = default.Addon.L(32319).format(
        title=title, channel=channel, time=time_txt, mins=mins_txt)
    try:
        xbmcgui.Dialog().notification(default.Addon.L(32318), msg,
                                      xbmcgui.NOTIFICATION_INFO, 10000, True)
    except Exception as e:
        log('reminder notification failed: {}'.format(e), 'error')


# ---------------------------------------------------------------------------
# VOD catalogue build + cache
# ---------------------------------------------------------------------------
def _entry_from_broadcast(b, ch):
    vtype, genre = classify(b)
    if vtype is None:
        return None  # not a film or series – skip for VOD
    try:
        st = default.to_local(b['starttime'], ch['utc'])
        en = default.to_local(b['endtime'], ch['utc'])
    except Exception:
        return None
    title = (b.get('title') or '').strip() or '?'
    return {
        'type': vtype,
        'title': title,
        'norm': normalize_title(title),
        'genre': genre,
        'plot': b.get('plot') or '',
        'plotoutline': b.get('plotoutline') or '',
        'episodename': b.get('episodename') or '',
        'episodenum': b.get('episodenum') or '',
        'firstaired': b.get('firstaired') or '',
        'year': b.get('year'),
        'rating': b.get('rating'),
        'thumb': b.get('thumbnail') or b.get('image') or '',
        'bid': b.get('broadcastid'),
        'cid': ch['cid'],
        'ch': ch['label'],
        'chicon': ch.get('icon') or '',
        'start_e': epoch_of(st),
        'end_e': epoch_of(en),
        'timer': bool(b.get('hastimer')),
        'dt': st,
    }


def hour_window():
    """Included hours of the day from settings (default: whole day, no gaps).

    Returns (h_from, h_to). h_to=24 means until the end of the day.
    A window like 20 > 2 is treated as overnight (20:00-02:00).
    """
    h_from = default.Addon.setting_int('vod_hour_from', 0)
    h_to = default.Addon.setting_int('vod_hour_to', 24)
    h_from = min(max(h_from, 0), 23)
    h_to = min(max(h_to, 1), 24)
    return h_from, h_to


def hour_in_window(hour, h_from, h_to):
    """True when the start hour is inside the included time window."""
    if h_from <= h_to:
        return h_from <= hour < h_to
    return hour >= h_from or hour < h_to      # overnight window


def collect_raw(days, progress=None):
    """Scan the guide: list of raw broadcast entries within [now, now+days].

    The scan pages through the whole guide of every channel, so entire days
    are never skipped (channels full of short programmes used to exhaust the
    first page long before the horizon, leaving whole days missing for
    movies and series).
    """
    channels = get_channels_vod('tv')
    entries = []
    now = datetime.now()
    limit = now + timedelta(days=days)
    h_from, h_to = hour_window()
    if (h_from, h_to) != (0, 24):
        log('VOD hour window: {:02d}:00-{:02d}:00'.format(h_from, h_to), 'info')

    # Decide UTC vs local once from a sample of currently-airing programmes
    # across the first channels. This avoids the old bug where the first
    # channel without an isactive programme forced UTC for everything.
    sample_bs = []
    for ch in channels[:15]:
        sample_bs.extend(get_broadcasts_vod(ch['channelid'], count=12))
        if sum(1 for b in sample_bs if b.get('isactive')) >= 3:
            break
    utc_mode = default.detect_utc(sample_bs)
    log('VOD EPG time mode: {} (sample {} broadcasts, {} active)'.format(
        'UTC' if utc_mode else 'local',
        len(sample_bs),
        sum(1 for b in sample_bs if b.get('isactive'))), 'info')

    PAGE = 200          # broadcasts per page
    MAX_PAGES = 30      # hard cap: 6000 broadcasts / channel is plenty
    total = max(len(channels), 1)
    raw_count = 0
    pages_total = 0
    for i, ch in enumerate(channels):
        if progress is not None and progress.iscanceled():
            return None
        if progress is not None:
            progress.update(int(i * 100 / total), ch.get('label') or ch.get('channel') or '')
        chinfo = {
            'cid': ch['channelid'],
            'label': ch.get('label') or ch.get('channel') or '?',
            'icon': ch.get('icon') or '',
            'utc': utc_mode,
        }
        start_idx = 0
        for _page in range(MAX_PAGES):
            bs = get_broadcasts_vod(ch['channelid'], count=PAGE,
                                    start_index=start_idx)
            if not bs:
                break
            pages_total += 1
            raw_count += len(bs)
            newest_dt = None
            for b in bs:
                # Track the newest start time even for skipped broadcasts so
                # the paging loop knows how far this channel is covered.
                try:
                    b_dt = default.to_local(b['starttime'], utc_mode)
                except Exception:
                    b_dt = None
                if b_dt is not None and (newest_dt is None or b_dt > newest_dt):
                    newest_dt = b_dt
                if b.get('wasactive') and not b.get('isactive'):
                    continue
                e = _entry_from_broadcast(b, chinfo)
                if e is None:
                    continue
                if e['end_e'] <= int(time.time()):
                    continue
                if e['dt'] > limit:
                    continue
                if not hour_in_window(e['dt'].hour, h_from, h_to):
                    continue
                entries.append(e)
            if len(bs) < PAGE:
                break            # end of the guide for this channel
            if newest_dt is not None and newest_dt > limit:
                break            # covered beyond the horizon
            start_idx += PAGE

    log('VOD collect_raw: {} channels, {} pages, {} raw broadcasts '
        '→ {} future entries'.format(len(channels), pages_total, raw_count,
                                     len(entries)), 'info')
    return entries


def group_titles(entries):
    """Group broadcast entries into titles: movie or series, with airings."""
    grouped = {}
    order = []
    for e in entries:
        if e['type'] == 'series':
            show = extract_series_title(e['title'])
            e['series_title'] = show or e['title']
            gkey = (e['type'], normalize_title(e['series_title']), e['genre'])
        else:
            e['series_title'] = e['title']
            gkey = (e['type'], e['norm'], e['genre'])
        if gkey not in grouped:
            grouped[gkey] = []
            order.append(gkey)
        grouped[gkey].append(e)

    titles = []
    for gkey in order:
        airings = grouped[gkey]
        airings.sort(key=lambda x: x['start_e'])
        e0 = airings[0]
        title = e0['series_title']
        t = {
            'type': e0['type'],
            'title': title,
            'norm': normalize_title(title),
            'genre': e0['genre'],
            'plot': e0['plot'],
            'plotoutline': e0['plotoutline'],
            'episodename': e0['episodename'],
            'episodenum': e0['episodenum'],
            'firstaired': e0.get('firstaired') or '',
            'year': e0.get('year'),
            'thumb': e0['thumb'],
            'chicon': e0['chicon'],
            'ch': e0['ch'],
            'airings': [{
                'bid': a['bid'], 'cid': a['cid'], 'ch': a['ch'],
                'start': a['start_e'], 'end': a['end_e'], 'timer': a['timer'],
                'thumb': a['thumb'],
                'episodename': a['episodename'], 'episodenum': a['episodenum'],
                'dt': a['start_e'],
            } for a in airings],
            'lib': None,
        }
        titles.append(t)
    return titles


def enrich(titles, use_library=True):
    """Attach library metadata (from the scrapers) to each title."""
    lib = LibraryMap().load() if (use_library and xbmc is not None) else None
    for t in titles:
        info = None
        if lib is not None:
            if t['type'] == 'movie':
                m = lib.match_movie(t['title'], t.get('year'))
                info = LibraryMap.extract(m)
            else:
                ep, show = lib.match_episode(t['title'], t.get('episodename'))
                if ep is not None:
                    info = LibraryMap.extract(ep)
                    # prefer show art for the poster card
                    sh = LibraryMap.extract(show, is_show=True) if show else None
                    if sh:
                        if not info.get('poster'):
                            info['poster'] = sh.get('poster')
                        if not info.get('fanart'):
                            info['fanart'] = sh.get('fanart')
                        if not info.get('ids'):
                            info['ids'] = sh.get('ids')
                elif show is not None:
                    info = LibraryMap.extract(show, is_show=True)
        if info is None:
            info = {}
        # EPG fallbacks (offline: EPG thumbnail only – the channel icon /
        # channel name fallback card is rendered by the window skin XML)
        if not info.get('poster'):
            info['poster'] = t.get('thumb') or ''
        if not info.get('fanart'):
            info['fanart'] = t.get('thumb') or ''
        if info.get('rating') is None and t.get('rating'):
            info['rating'] = t.get('rating')
        if not info.get('plot'):
            info['plot'] = t.get('plot') or t.get('plotoutline') or ''
        if info.get('year') is None:
            fa = t.get('firstaired') or ''
            if fa[:4].isdigit():
                info['year'] = int(fa[:4])
        t['lib'] = info
    return titles


def build_catalogue(days, use_library=True, progress=None):
    entries = collect_raw(days, progress)
    if entries is None:
        return None
    log('VOD build: {} raw future entries'.format(len(entries)), 'info')
    titles = group_titles(entries)
    enrich(titles, use_library)
    movies = sorted([t for t in titles if t['type'] == 'movie'],
                    key=lambda t: t['airings'][0]['start'])
    series = sorted([t for t in titles if t['type'] == 'series'],
                    key=lambda t: t['airings'][0]['start'])
    log('VOD build: {} titles → {} movies, {} series'.format(
        len(titles), len(movies), len(series)), 'info')
    if titles and not movies and not series:
        # Should not happen – every title has type movie|series
        log('VOD build: all titles dropped after classification!', 'error')
    return {'days': days, 'movies': movies, 'series': series}


# ---------------------------------------------------------------------------
# Cache
# ---------------------------------------------------------------------------
def cache_path():
    return CACHE_FILE


def load_cache(days, ttl_minutes):
    if xbmcvfs is None:
        return None
    try:
        if not xbmcvfs.exists(cache_path()):
            return None
        f = xbmcvfs.File(cache_path())
        raw = f.read()
        f.close()
        data = json.loads(raw)
        if data.get('days') != int(days):
            return None
        age = time.time() - float(data.get('built', 0))
        if age > ttl_minutes * 60:
            return None
        # Never reuse an empty catalogue – force a fresh scan so a previous
        # failed detection (wrong timezone, empty EPG moment, etc.) does not
        # stick for the whole TTL window.
        if not data.get('movies') and not data.get('series'):
            log('VOD cache is empty → ignoring, will rescan', 'info')
            return None
        return data
    except Exception as e:
        log('cache load failed: {}'.format(e), 'debug')
        return None


def load_cache_any():
    """Latest catalogue from cache regardless of TTL / day count.

    Used for the home-screen condensed views: a slightly stale preview is
    better than no preview, and it never triggers a scan.
    """
    if xbmcvfs is None:
        return None
    try:
        if not xbmcvfs.exists(cache_path()):
            return None
        f = xbmcvfs.File(cache_path())
        raw = f.read()
        f.close()
        return json.loads(raw)
    except Exception as e:
        log('cache load (any) failed: {}'.format(e), 'debug')
        return None


def save_cache(data):
    try:
        if xbmcvfs is None:
            return
        data = dict(data)
        data['built'] = time.time()
        if not xbmcvfs.exists(STATE_DIR):
            xbmcvfs.mkdirs(STATE_DIR)
        f = xbmcvfs.File(cache_path(), 'w')
        f.write(json.dumps(data, ensure_ascii=False))
        f.close()
        log('VOD cache saved ({} movies, {} series)'.format(
            len(data.get('movies', [])), len(data.get('series', []))), 'info')
    except Exception as e:
        log('cache save failed: {}'.format(e), 'error')


def get_catalogue(progress=None, force=False):
    """Catalogue for the window: cached when fresh, else scan the guide."""
    days = max(1, default.Addon.setting_int('vod_days', 7))
    ttl = max(1, default.Addon.setting_int('vod_cache_minutes', 30))
    # Library enrichment is OFF by default – its data comes from online
    # scrapers (IMDb/TMDb), and the view must work without internet.
    use_library = default.Addon.setting_bool('vod_use_library', False)
    if not force:
        data = load_cache(days, ttl)
        if data:
            log('VOD catalogue from cache', 'debug')
            return data
    data = build_catalogue(days, use_library, progress)
    if data is not None:
        save_cache(data)
    return data
