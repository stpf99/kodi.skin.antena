# -*- coding: utf-8 -*-
"""Antena Companion background service.

Remembers the last played channel and watched genres (ServiceMonitor),
fires VOD reminders (vod.py) as on-screen notifications and refreshes the
condensed views shown when hovering the home-screen tabs (Przewodnik,
Rekomendowane, Filmy w TV, Seriale w TV ...). The preview data is written
as Home window properties – the skin only reads them, fully offline.
"""
import time

import default

if __name__ == '__main__':
    monitor = default.ServiceMonitor()
    last_reminder_check = 0
    last_widget = 0.0
    widgets_initialized = False
    while not monitor.abortRequested():
        monitor.try_autostart()
        now = time.time()
        if now - last_reminder_check >= 10:
            last_reminder_check = now
            default.check_reminders_and_fire()
        # Home-screen condensed views: initial fill as soon as the PVR is
        # ready, then on the interval from the settings (default 30 min).
        if default.is_pvr_ready():
            if not widgets_initialized:
                widgets_initialized = True
                last_widget = now
                default.update_home_widgets(force_scan=True)
                default.maybe_build_catalogue_background()
            elif now - last_widget >= default.widget_interval_seconds():
                last_widget = now
                default.update_home_widgets(force_scan=True)
                default.maybe_build_catalogue_background()
        if monitor.waitForAbort(1):
            break
